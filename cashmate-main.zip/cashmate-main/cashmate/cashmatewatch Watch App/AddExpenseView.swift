//
//  AddExpenseView.swift
//  cashmate
//
//  Created by student on 04/06/25.
//


import SwiftUI
import SwiftData

struct AddExpenseView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var context

    @State private var amountText = ""

    var body: some View {
        VStack {
            TextField("Amount", text: $amountText)
                
                .padding()

            Button("Save") {
                if let amount = Double(amountText) {
                    let newExpense = Expense(amount: amount)
                    context.insert(newExpense)
                    try? context.save()
                    dismiss()
                }
            }
            .buttonStyle(.borderedProminent)

            Button("Cancel") {
                dismiss()
            }
        }
        .padding()
    }
}
