//
//  HistoryView.swift
//  cashmate
//
//  Created by student on 04/06/25.
//


import SwiftUI
import SwiftData

struct HistoryView: View {
    @Query(sort: \Expense.date, order: .reverse) var expenses: [Expense]

    var body: some View {
        List {
            ForEach(expenses) { expense in
                VStack(alignment: .leading) {
                    Text("Rp. \(Int(expense.amount))")
                    Text(expense.date.formatted(date: .abbreviated, time: .shortened))
                        .font(.caption)
                        .foregroundColor(.gray)
                }
            }
        }
    }
}
