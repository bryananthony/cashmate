//
//  DashboardView.swift
//  cashmate
//
//  Created by student on 04/06/25.
//


import SwiftUI
import SwiftData

struct DashboardView: View {
    @Environment(\.modelContext) private var context
    @Query(sort: \Expense.date, order: .reverse) private var expenses: [Expense]

    @State private var budget: Double = 500_000
    @State private var showingAddExpense = false

    var totalSpent: Double {
        expenses.reduce(0) { $0 + $1.amount }
    }

    var remaining: Double {
        budget - totalSpent
    }

    var body: some View {
        VStack(spacing: 10) {
            Text("Budget: Rp. \(Int(budget))")
            Text("Spent: Rp. \(Int(totalSpent))")
            Text("Left: Rp. \(Int(remaining))")
                .foregroundColor(remaining >= 0 ? .green : .red)

            Button("Add Expense") {
                showingAddExpense = true
            }
            .buttonStyle(.borderedProminent)
        }
        .sheet(isPresented: $showingAddExpense) {
            AddExpenseView()
        }
        .padding()
    }
}
