//
//  SettingsView.swift
//  cashmate
//
//  Created by student on 04/06/25.
//


import SwiftUI

struct SettingsView: View {
    @AppStorage("goal") var goal: String = "New Phone"
    @AppStorage("goalAmount") var goalAmount: Double = 3_000_000
    @AppStorage("budget") var budget: Double = 500_000

    var body: some View {
        Form {
            Section("Goal") {
                TextField("Goal Name", text: $goal)
                TextField("Goal Amount", value: $goalAmount, format: .number)
            }

            Section("Budget") {
                TextField("Monthly Budget", value: $budget, format: .number)
            }
        }
    }
}
