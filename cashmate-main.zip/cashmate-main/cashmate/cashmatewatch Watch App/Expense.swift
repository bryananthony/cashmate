
import Foundation
import SwiftData

@Model
final class Expense {
    var amount: Double
    var date: Date

    init(amount: Double, date: Date = .now) {
        self.amount = amount
        self.date = date
    }
}
