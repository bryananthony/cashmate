package View;

import javax.swing.*;

public class BoxLayoutXView extends JFrame {

    public BoxLayoutXView() {
        setTitle("BoxLayoutXView"); // Title
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Close Operation
        setSize(500,500); // Size
        setLayout(new BoxLayout(getContentPane(),BoxLayout.X_AXIS)); // Set Layout

        // Button
        for (int i = 0; i < 5; i++){
            add(new JButton("Button " + (i+1)));
        }
    }
}
