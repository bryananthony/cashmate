package View;

import javax.swing.*;
import java.awt.*;

public class GroupLayoutView extends JFrame {
    private JTextField nameField = new JTextField();
    private JTextField emailField = new JTextField();
    private JButton submitButton = new JButton("Submit");
    private JLabel welcomeLabel;

    public GroupLayoutView() {
        setTitle("Group Layout");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500,500);

        // Label
        JLabel nameLabel = new JLabel("Name:");
        JLabel emailLabel = new JLabel("Email:");
        welcomeLabel = new JLabel();
        welcomeLabel.setForeground(Color.red);

        JPanel panel = new JPanel();
        GroupLayout layout = new GroupLayout(panel);
        panel.setLayout(layout);
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);

        // Horizontal Layout
        layout.setHorizontalGroup(
                layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                        .addComponent(nameLabel)
                                        .addComponent(emailLabel))
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                        .addComponent(nameField)
                                        .addComponent(emailField)))
                        .addComponent(submitButton, GroupLayout.Alignment.CENTER)
                        .addComponent(welcomeLabel, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)

        );



        // Vertical Layout
        layout.setVerticalGroup(
                layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                .addComponent(nameLabel)
                                .addComponent(nameField))
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                .addComponent(emailLabel)
                                .addComponent(emailField))
                        .addComponent(submitButton)
                        .addComponent(welcomeLabel, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        );

        setContentPane(panel);
        setLocationRelativeTo(null);

        submitButton.addActionListener(e -> {
            String name = nameField.getText();
            String email = emailField.getText();
            welcomeLabel.setText("Hello " + name + "!\n" + email + " succesfully registered!");
        });
    }
}
