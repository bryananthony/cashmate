package View;

import javax.smartcardio.Card;
import javax.swing.*;
import java.awt.*;

public class CardLayoutView extends JFrame {
    private JPanel cardsPanel;
    private CardLayout cardLayout;

    public CardLayoutView() {
        setTitle("CardLayoutView"); // Title
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Close Operation
        setSize(500,500); // Size

        cardLayout = new CardLayout();
        cardsPanel = new JPanel(cardLayout);

        cardsPanel.add(createCard("Card 1"), "Card 1");
        cardsPanel.add(createCard("Card 2"), "Card 2");
        cardsPanel.add(createCard("Card 3"), "Card 3");
        cardsPanel.add(createCard("Card 4"), "Card 4");
        cardsPanel.add(createCard("Card 5"), "Card 5");

        JPanel buttonPanel = new JPanel();
        JButton btnPrev = new JButton("Prev");
        JButton btnNext = new JButton("Next");

        buttonPanel.add(btnPrev);
        buttonPanel.add(btnNext);

        btnPrev.addActionListener(e -> cardLayout.previous(cardsPanel));
        btnNext.addActionListener(e -> cardLayout.next(cardsPanel));

        setLayout(new BorderLayout());
        add(cardsPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

    }

    private JPanel createCard(String labelText){
        JPanel card = new JPanel();
        card.add(new JLabel(labelText));
        return card;
    }
}
