package View;

import javax.swing.*;
import java.awt.*;

public class BorderLayoutView extends JFrame {
    public BorderLayoutView() {
        setTitle("BorderLayoutView"); // Title
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Close Operation
        setSize(500,500); // Size
        setLayout(new BorderLayout()); // Set Layout

        // Button
        add(new JButton("North"), BorderLayout.NORTH);
        add(new JButton("South"), BorderLayout.SOUTH);
        add(new JButton("East"), BorderLayout.EAST);
        add(new JButton("West"), BorderLayout.WEST);
        add(new JButton("Center"), BorderLayout.CENTER);
    }
}
