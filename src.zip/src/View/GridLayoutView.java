package View;

import javax.swing.*;
import java.awt.*;

public class GridLayoutView extends JFrame {
    public GridLayoutView() {
        setTitle("GridLayoutView"); // Title
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Close Operation
        setSize(500,500); // Size
        setLayout(new GridLayout(5,5)); // Set Layout

        // Button
        for (int i = 0; i < 25; i++){
            add(new JButton("Button " + (i+1)));
        }
    }
}
