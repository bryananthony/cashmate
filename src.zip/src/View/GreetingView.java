package View;

import javax.swing.*;
import java.awt.*;

public class GreetingView extends JFrame {
    JLabel greetingLabel = new JLabel("Hello World!");

    public GreetingView() {
        setTitle("Greeting");
        setSize(500, 500);
        setLayout(new FlowLayout());

        add(new JButton("Flow Layout"));
        add(new JButton("Box Layout X"));
        add(new JButton("Box Layout Y"));
        add(new JButton("Border Layout"));
        add(new JButton("Grid Layout"));
        add(new JButton("Card Layout"));
        add(new JButton("Group Layout"));
        add(new JButton("Grid Bag Layout"));



//        add(greetingLabel);
//        add(new JLabel("Hello World! part 2"));
    }
}
