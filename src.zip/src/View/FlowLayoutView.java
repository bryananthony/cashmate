package View;

import javax.swing.*;
import java.awt.*;

public class FlowLayoutView extends JFrame {
    public FlowLayoutView() {
        setTitle("FlowLayoutView"); // Title
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Close Operation
        setSize(500,500); // Size
        setLayout(new FlowLayout()); // Set Layout

        // Button
        for (int i = 0; i < 5; i++){
            add(new JButton("Button " + (i+1)));
        }
    }
}
