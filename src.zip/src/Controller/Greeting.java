package Controller;

public class Greeting {

}
