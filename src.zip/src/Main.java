import View.*;

import javax.smartcardio.Card;
import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        GreetingView view = new GreetingView();
        view.setVisible(true);
    }
}